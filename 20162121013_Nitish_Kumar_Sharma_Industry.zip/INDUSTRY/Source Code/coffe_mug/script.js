// changeContent_connectAction
data = [
    [
        {
            "id": "startup",
            "header": "StartUp Investment",
            "tagline": "We help founders build and investors invest in the next big thing.",
            "item1_h4": "$9,000+",
            "item2_h4": "1,50,000+",
            "item1_p": "Investors and Founders",
            "item2_p": "Connections made"
        },
        {
            "id": "career",
            "header": "Career Opportunities",
            "tagline": "We help Founders/CEO's to find the right talent for their startups.",
            "item1_h4": "5,00,000+",
            "item2_h4": "1.2 million",
            "item1_p": "Proffessionals",
            "item2_p": "Connections"
        },
        {
            "id": "mentorship",
            "header": "Mentorship",
            "tagline": "We help mentors and mentees to connect and grow together.",
            "item1_h4": "25,000+",
            "item2_h4": "1,20,000+",
            "item1_p": "Mentors and Mentees",
            "item2_p": "Connections made"
        },
        {
            "id": "brainstorming",
            "header": "Brainstorming",
            "tagline": "We help you to connect with like minded people and brainstorm ideas.",
            "item1_h4": "5,00,000+",
            "item2_h4": "1.2 million",
            "item1_p": "Proffessionals",
            "item2_p": "Connections made"
        }
    ]    
];


function changeContent_connectAction(props) {
    var id = props;
    var header = "";
    var tagline = "";
    var item1_h4 = "";
    var item2_h4 = "";
    var item1_p = "";
    var item2_p = "";
    var img = "";
    var userInfo = "";

    for(var i=0; i<data.length; i++){
        for(var j=0; j<data[i].length; j++){
            if(data[i][j].id == id){
                header = data[i][j].header;
                tagline = data[i][j].tagline;
                item1_h4 = data[i][j].item1_h4;
                item2_h4 = data[i][j].item2_h4;
                item1_p = data[i][j].item1_p;
                item2_p = data[i][j].item2_p;
            }
        }
    }

    document.getElementById("connect-action-header").innerHTML = header;
    document.getElementById("connect-action-tagline").innerHTML = tagline;
    document.getElementById("connect-action-item1").children[0].innerHTML = item1_h4;
    document.getElementById("connect-action-item2").children[0].innerHTML = item2_h4;
    document.getElementById("connect-action-item1").children[1].innerHTML = item1_p;
    document.getElementById("connect-action-item2").children[1].innerHTML = item2_p;

    const connectAction = document.querySelector('.active');
    connectAction.classList.remove('active');
    document.getElementById(id).classList.add('active');

}
