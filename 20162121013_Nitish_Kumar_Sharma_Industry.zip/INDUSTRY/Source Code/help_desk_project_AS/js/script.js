async function validateForm(event) {
    event.preventDefault();

    var email = document.getElementById("email").value;
    var tname = document.getElementById("tname").value;
    var tdesc = document.getElementById("tdesc").value;

    var data = {
        "Email": email,
        "Ticket Name": tname,
        "Ticket Description": tdesc
    };

    var showMessage = document.querySelector(".show-message");

    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    var validTName = /^[a-zA-Z][a-zA-Z0-9]+$/;

    if ((email == "" || email == null) && (tname == "" || tname == null) && (tdesc == "" || tdesc == null)
    ) {
        showMessage.classList.add("message-error");
        showMessage.innerHTML = "All fields must be filled out";
        return false;
    } else if (email == "" || email == null) {
        showMessage.classList.add("message-error");
        showMessage.innerHTML = "Email must be filled out";
        return false;
    } else if (tname == "" || tname == null) {
        showMessage.classList.add("message-error");
        showMessage.innerHTML = "Ticket name must be filled out";
        return false;
    } else if (tdesc == "" || tdesc == null) {
        showMessage.classList.add("message-error");
        showMessage.innerHTML = "Ticket description must be filled out";
        return false;
    } else if (email.match(validRegex) == null) {
        showMessage.classList.add("message-error");
        showMessage.innerHTML = "Please enter a valid email address";
        return false;
    } else if (tname.match(validTName) == null) {
        showMessage.classList.add("message-error");
        showMessage.innerHTML = "Ticket name must br character";
        return false;
    } else {
        showMessage.classList.remove("message-error");
        showMessage.innerHTML = "";
        return [true,data];
    }
}

async function addLoader(){
    var lh = document.querySelector(".loader-hidden");
    
    lh.classList.remove("loader-hidden");
    lh.classList.add("loader");

    console.log("add loader done");
    
    setTimeout(async ()=> {
        await removeLoader();
    }, 2000);
    
}

async function removeLoader(){
    var lh = document.querySelector(".loader");

    lh.classList.remove("loader");
    lh.classList.add("loader-hidden");
    
    console.log("remove loader done");
}

// creating modal
async function promptMessage(values) {
    var modal = document.querySelector(".modal-hidden");

    var modalContent = document.createElement("div");
    modalContent.classList.add("modal-content");
    
    var modalHeader = document.createElement("div");
    var modalHeaderTitle = document.createElement("h2");
    modalHeaderTitle.innerHTML = "Ticket Created";
    modalHeader.appendChild(modalHeaderTitle);
    
    var modalBody = document.createElement("div");

    for (let index = 0; index < Object.keys(values).length; index++) {
        var modalMessage = document.createElement("div");
        modalMessage.classList.add("modal-message");
        var element = Object.keys(values)[index];
        var value = Object.values(values)[index];
        modalMessage.innerHTML = `${element}`;
        modalMessage.innerHTML += `<br>`;
        modalMessage.innerHTML += `${value}`;
        modalBody.appendChild(modalMessage);
    }
    
    var modalButtonDiv = document.createElement("div");
    var modalButton = document.createElement("button");
    modalButton.classList.add("modal-close-btn");
    modalButton.setAttribute('onclick', 'return removeModal()');
    modalButton.innerHTML = "Close";
    modalButtonDiv.appendChild(modalButton);

    modalContent.appendChild(modalHeader);
    modalContent.appendChild(modalBody);
    modalContent.appendChild(modalButtonDiv);

    modal.appendChild(modalContent);
    document.body.appendChild(modal);

    await displayModal();
}

async function displayModal(){
    var mh = document.querySelector(".modal-hidden");
    mh.classList.remove("modal-hidden");
    mh.classList.add("modal");
    console.log("display modal done");
}

async function removeModal(){
    var mc = document.querySelector(".modal-content");
    mc.parentNode.removeChild(mc);
    
    var mh = document.querySelector(".modal");
    mh.classList.remove("modal");
    mh.classList.add("modal-hidden");
    console.log("remove modal done");

    await deleteInputField();
}

async function deleteInputField(){

    var email = document.getElementById("email");
    email.value = "";

    var tname = document.getElementById("tname");
    tname.value = "";

    var tdesc = document.getElementById("tdesc");
    tdesc.value = "";

}


async function nextPass(e){

    const vf = await validateForm(e);

    if(vf[0]){
        console.log("validate done");
        await addLoader();
        await promptMessage(vf[1]);
    }

    console.log("form complete");
}
