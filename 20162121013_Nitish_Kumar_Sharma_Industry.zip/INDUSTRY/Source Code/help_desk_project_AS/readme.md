## Help Desk Project
- Build a help desk ticketing system using HTML, CSS, and JavaScript.
- The system should allow users to create tickets, assign them to a department, and assign them to a user.
- The system should allow users to view all tickets, view tickets by department, and view tickets by user.

## Requirements
- Create a ticket
- Assign a ticket to a department
- Assign a ticket to a user
- View all tickets
- View tickets by department
- View tickets by user

## Bonus
- Add a status to tickets
- Add a priority to tickets
- Add a due date to tickets
- Add a search feature to tickets
- Add a filter feature to tickets
- Add a sort feature to tickets

<!-- ## Notes
- Use the `tickets.json` file to store ticket data.
- Use the `users.json` file to store user data.
- Use the `departments.json` file to store department data.
- Use the `statuses.json` file to store status data.
- Use the `priorities.json` file to store priority data.
- Use the `due_dates.json` file to store due date data.
- Use the `search.json` file to store search data. -->
<!-- 
## Resources
- [JavaScript Date Object](https://www.w3schools.com/jsref/jsref_obj_date.asp)
- [JavaScript Array Methods](https://www.w3schools.com/js/js_array_methods.asp)
- [JavaScript Array Filter](https://www.w3schools.com/jsref/jsref_filter.asp)
- [JavaScript Array Sort](https://www.w3schools.com/jsref/jsref_sort.asp)
- [JavaScript Array Find](https://www.w3schools.com/jsref/jsref_find.asp)
- [JavaScript Array FindIndex](https://www.w3schools.com/jsref/jsref_findindex.asp) -->