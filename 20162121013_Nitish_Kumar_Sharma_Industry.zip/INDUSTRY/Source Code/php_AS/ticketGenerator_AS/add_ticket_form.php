<?php
    session_start();
    if(isset($_SESSION['loginFlag']) && $_SESSION['loginFlag'] == 1){
        $email = $_SESSION['email'];
        $role = $_SESSION['role'];
        $fname = $_SESSION['fname'];
    }else{
        header('Location: login.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Ticket Form</title>
    <!-- <link rel="stylesheet" href="../../css/ticket_form.css"> -->
</head>
<body>
    <?php include 'header.php';?>
    
    <main id="form-main">
        <!-- create a path -->
        <div class="path">
            <a href="index.php" class="back-to-home">Back to Home</a>
        </div>

        <!-- creating add ticket form -->
        <div class="container form">
            <div class="caption">Create Ticket</div>
            <div class="add-ticket-form">
                <form action="" method="post" id="add-ticket-formform" enctype="multipart/form-data">
                    <div class="form-items">
                        <label for="email">email</label> <!-- email for user -->
                        <?php if(isset($_SESSION['email'])){ ?>
                            <input type="text" name="email" id="email" value="<?php echo $_SESSION['email']; ?>" readonly>
                        <?php }else{ ?>
                            <input type="text" name="email" id="email" placeholder="Enter your email">
                        <?php } ?>
                    </div>               
                    <div class="form-items">
                        <label for="tname">T Name</label> <!-- tname is the name of the ticket -->
                        <input type="text" name="tname" id="tname" placeholder="Enter ticket name">
                    </div>
                    <div class="form-items">
                        <label for="tdesc">Message</label> <!-- textarea for the message -->
                        <textarea name="textarea" id="tdesc" cols="25" rows="5" placeholder="Ticket Description"></textarea>
                    </div>
                    <div class="form-items">
                        <label for="file"></label>
                        <input type="file" id="file" name="files[]" multiple>
                    </div>


                    <div class="form-items">
                        <button type="submit" name="submit" id="submit">submit</button>
                    </div>

                    <!-- display message -->
                    <span class="show-message">
                    
                    </span>
                </form>
               
            </div>
        </div>
    </main>

    <div class="loader-hidden"></div>
    <div class="modal-hidden"></div>
</body>

<script type="text/javascript">
    const submit = document.querySelector("#add-ticket-formform");
    
    
    submit.addEventListener("submit", (e)=>{
        e.preventDefault();
        const formData = new FormData();
        const files = document.querySelector("#file").files;
        const email = document.querySelector("#email").value;
        const tname = document.querySelector("#tname").value;
        const tdesc = document.querySelector("#tdesc").value;
        const submit = document.querySelector("#submit").value;
        formData.append("email", email);
        formData.append("tname", tname);
        formData.append("tdesc", tdesc);
        formData.append("submit", submit);
        for(let i = 0; i < files.length; i++){
            let file = files[i];
            formData.append("files[]", file);
        }
        
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "validateForm.php", true);
        xhr.onload = ()=>{
            if(xhr.readyState === XMLHttpRequest.DONE){
                if(xhr.status === 200){
                    let data = xhr.response;
                    console.log(data);
                    // {"email":"nitish@gg.com","tname":"nn","tdesc":"n","files":["uploads\/Almashines-logo_65af686e399a67.43739411.png","uploads\/Almashines-Support_65af686e39beb3.84998668.png","uploads\/alumni-events_65af686e39e178.84604337.png"],"successMessage":"File insertion successful<br>","errorMessage":null}
                    // format the data
                    data = JSON.parse(data);
                    if(data.successMessage != null){
                        document.querySelector(".show-message").innerHTML = data.successMessage;
                        document.querySelector(".show-message").style.color = "green";
                        
                        // add loader using async function
                        setTimeout(async()=>{                            
                            await addLoader();
                            // add delay to show the loader
                            setTimeout(async()=>{
                                await promptMessage(data);
                            }, 2000);
                            // prompt message using async function
                        }, 500);

                        // clear the form                        
                        document.querySelector("#tname").value = "";
                        document.querySelector("#tdesc").value = "";
                        document.querySelector("#file").value = "";
                        // remove the message after 3 seconds
                        document.querySelector(".show-message").innerHTML = "";
                    }else{
                        document.querySelector(".show-message").innerHTML = data.errorMessage;
                        document.querySelector(".show-message").style.color = "red";
                    }
                }
            }
        }
        xhr.send(formData);


    });

    async function addLoader(){
        var lh = document.querySelector(".loader-hidden");

        lh.classList.remove("loader-hidden");
        lh.classList.add("loader");
        console.log("add loader done");
        
        setTimeout(async ()=> {
            await removeLoader();
        }, 2000);
    }

    async function removeLoader(){
        var lh = document.querySelector(".loader");
        lh.classList.remove("loader");
        lh.classList.add("loader-hidden");        
        console.log("remove loader done");
    }

    async function promptMessage(values) {
    var modal = document.querySelector(".modal-hidden");

    var modalContent = document.createElement("div");
    modalContent.classList.add("modal-content");
    
    var modalHeader = document.createElement("div");
    var modalHeaderTitle = document.createElement("h2");
    modalHeaderTitle.innerHTML = "Ticket Created";
    modalHeader.appendChild(modalHeaderTitle);
    
    var modalBody = document.createElement("div");

    for (let index = 0; index < Object.keys(values).length - 3; index++) {
        // email, tname, tdesc
        var modalBodyItem = document.createElement("div");
        modalBodyItem.classList.add("modal-message");
        modalBodyItem.innerHTML = Object.keys(values)[index] + ": " + Object.values(values)[index];
        modalBody.appendChild(modalBodyItem);
    }

    var modalBodyItem = document.createElement("div");
    modalBodyItem.classList.add("modal-img");
    for (let index = 0; index < values.files.length; index++) {
        // files
        var modalBodyItemImg = document.createElement("a");
        modalBodyItemImg.setAttribute("href", values.files[index]);
        modalBodyItemImg.setAttribute("target", "_blank");
        modalBodyItemImg.innerHTML = "File " + (index + 1);
        modalBodyItem.appendChild(modalBodyItemImg);
    }
    modalBody.appendChild(modalBodyItem);
    
    var modalButtonDiv = document.createElement("div");
    var modalButton = document.createElement("button");
    modalButton.classList.add("modal-close-btn");
    modalButton.setAttribute('onclick', 'return removeModal()');
    modalButton.innerHTML = "Close";
    modalButtonDiv.appendChild(modalButton);

    modalContent.appendChild(modalHeader);
    modalContent.appendChild(modalBody);
    modalContent.appendChild(modalButtonDiv);

    modal.appendChild(modalContent);
    document.body.appendChild(modal);

    await displayModal();
}

async function displayModal(){
    var mh = document.querySelector(".modal-hidden");
    mh.classList.remove("modal-hidden");
    mh.classList.add("modal");
    console.log("display modal done");
}

async function removeModal(){
    var mc = document.querySelector(".modal-content");
    mc.parentNode.removeChild(mc);
    
    var mh = document.querySelector(".modal");
    mh.classList.remove("modal");
    mh.classList.add("modal-hidden");
    console.log("remove modal done");
}
</script>

</html>