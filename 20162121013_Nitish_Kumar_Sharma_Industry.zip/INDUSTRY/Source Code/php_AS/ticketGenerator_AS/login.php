<?php
    session_start();
    if(isset($_SESSION['loginFlag']) && $_SESSION['loginFlag'] == 1){
        header('Location: index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title> 
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <?php include 'header.php';?>
    
    <main class="login-main">
    <div class="container login-form">
        <div class="caption">Login</div>
        <form action="" method="post" id="loginForm">
            <div class="form-items">
                <label for="email">Email</label>
                <input type="text" name="email" id="email">
            </div>
            <div class="form-items">
                <label for="password">Password</label>
                <input type="password" name="password" id="password">
            </div>
            <div class="form-items">
                <label for="repassword">Re-Password</label>
                <input type="password" name="repassword" id="repassword">
            </div>
            <div class="form-items">
                <input type="submit" value="Login">
            </div>
            <div class="login-show-message"></div>
        </form>
    </div>
    </main>
</body>
<script type="text/javascript">
    const loginForm = document.querySelector('#loginForm');

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.querySelector('#email').value;
        const password = document.querySelector('#password').value;
        const repassword = document.querySelector('#repassword').value;

        // let formData = {
        //     email: email,
        //     password: password,
        //     repassword: repassword
        // }

        // formData = JSON.stringify(formData);

        if(email == '' || password == '' || repassword == ''){
            document.querySelector('.login-show-message').innerHTML = 'Please fill all the fields';
            document.querySelector('.login-show-message').style.color = 'red';
        }else{
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'loginData.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onload = function(){
                if(this.status == 200){
                    let response = this.responseText;
                    console.log(response);                      
                    response = JSON.parse(response);
                    if(response.LoginFlag == 1){
                        document.querySelector('.login-show-message').innerHTML = response.LoginMessage;
                        document.querySelector('.login-show-message').style.color = 'red';
                    }else{
                        document.querySelector('.login-show-message').innerHTML = response.LoginMessage;
                        document.querySelector('.login-show-message').style.color = 'green';
                        setTimeout(() => {
                            window.location.href = 'index.php';
                        }, 1000);
                    }
                }
            }
            xhr.send(`email=${email}&password=${password}&repassword=${repassword}`);
        }
    });
</script>
</html>