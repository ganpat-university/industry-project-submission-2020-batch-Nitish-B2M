<?php
    if(isset($_SESSION['loginFlag']) && $_SESSION['loginFlag'] == 1){
        $email = $_SESSION['email'];
        $role = $_SESSION['role'];
        $fname = $_SESSION['fname'];
    }else{
        $fname = 'Guest';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
        <div class="header">
            <div class="title">
                Welcome to Help Desk
            </div>
            <span class="author-remarks">
                <?php echo 'By '.$fname; ?>
            </span>
        </div>
    </header>
</body>
</html>