<!-- fetch data from session if session created -->
<?php
    session_start();
    if(isset($_SESSION['loginFlag']) && $_SESSION['loginFlag'] == 1){
        $email = $_SESSION['email'];
        $fname = $_SESSION['fname'];
    }else{
        header('Location: login.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
</head>
<body>
    <?php include 'header.php';?>
    <main>
        <div class="main container">
            <div class="add-ticket-btn">
                <a href="add_ticket_form.php">
                    Add New Ticket
                </a>
            </div>
        </div>
    </main>
    <!-- logout -->
    <div class="logout-btn">
        <a href="logout.php">Logout</a>
    </div>
    
</body>
    
</body>
</html>