<?php
    session_start();
    if(isset($_SESSION['loginFlag']) && $_SESSION['loginFlag'] == 1){
        $email = $_SESSION['email'];
        $fname = $_SESSION['fname'];
    }else{
        header('Location: login.php');
    }
?>
<?php
    try{
        // data come from add_ticket_form.php using xhr.send(formData)
        $email = $_POST['email'];
        $tname = $_POST['tname'];
        $tdesc = $_POST['tdesc'];
    
        $fileArray = array();
        
        $successMessage = null;
        $errorMessage = null;
        $errorFlag = 0;
        $dbConnectionMessage = null;
    
        // validate data
        $validate_email = test_input($email);
        $validate_tname = test_input($tname);
        $validate_tdesc = test_input($tdesc);

        if($validate_email[1] == 0 || $validate_tname[1] == 0 || $validate_tdesc[1] == 0 ){
            $errorFlag = 1;
            $errorMessage = "Please fill in all the fields";
        } else if(!preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$/", $validate_email[0])){
            $errorFlag = 1;
            $errorMessage = "Email is not valid";
        } elseif(!preg_match("/^[a-zA-Z][a-zA-Z0-9 ]+$/", $validate_tname[0])){
            $errorFlag = 1;
            $errorMessage = "Ticket name is not valid, it should start with atleast two letters";
        } elseif(!preg_match("/^[a-zA-Z0-9 ]*$/", $validate_tdesc[0])){
            $errorFlag = 1;
            $errorMessage = "Ticket description is not valid";
        } else {
            // files come from add_ticket_form.php using xhr.send(formData)
            if(!isset($_FILES["files"])){
                $errorFlag = 1;
                $errorMessage = "Please select a file";
            } else {
                $files = $_FILES['files'];
                $fileCount = count($files["name"]);
                for($i = 0; $i < $fileCount; $i++){
                    $fileName = $files["name"][$i];
                    $fileSize = $files["size"][$i];
                    $fileError = $files["error"][$i];
                    $fileType = $files["type"][$i];
                    $fileTempName = $files["tmp_name"][$i];

                    // check extension
                    $fileExt = explode(".", $fileName);
                    $fileActualExt = strtolower(end($fileExt));

                    $allowed = array("jpg", "jpeg", "png", "gif");
                    if(in_array($fileActualExt, $allowed)){
                        if($fileSize < 1000000){
                            if($fileError === 0){
                                $fileNameNew = reset($fileExt)."_".uniqid("", true).".".$fileActualExt;
                                $fileDestination = "uploads/".$fileNameNew;
                                move_uploaded_file($fileTempName, $fileDestination);
                                array_push($fileArray, $fileDestination);
                            } else {
                                $errorFlag = 1;
                                $errorMessage = "File upload failed";
                            }
                        } else {
                            $errorFlag = 1;
                            $errorMessage = "File size is too big";
                        }
                    } else {
                        $errorFlag = 1;
                        $errorMessage = "File type is not allowed";
                    }
                }
            }
        }
    
        if($errorFlag == 0){
            // connect to database
            $dbConnection = mysqli_connect("localhost", "root", "", "help_desk");
            if(!$dbConnection){
                $dbConnectionMessage = "Database connection failed";
                // response back to add_ticket_form.php
                echo $dbConnectionMessage;
            } else {
                $dbConnectionMessage = "Database connection successful";
                // insert data into database
                $sql = "INSERT INTO tickets (u_id, tname, description) VALUES (1, '$tname', '$tdesc')";
                $result = mysqli_query($dbConnection, $sql);
                if(!$result){
                    $errorMessage = "Data insertion failed in tickets table";
                    echo $errorMessage;
                } else {
                    $successMessage = "Data insertion successful";

                    # insert files into database
                    $fileCount = count($fileArray);
                    for($i = 0; $i < $fileCount; $i++){
                        $filePsth = $fileArray[$i];
                        $sql2 = "INSERT INTO filepath (t_id, filePath) VALUES (19, '$filePsth')";
                        $result2 = mysqli_query($dbConnection, $sql2);
                        if(!$result2){
                            $errorMessage = "File insertion failed";
                        } else {
                            $successMessage = "File insertion successful";
                        }
                    }
                }
                // response back to add_ticket_form.php
                $dataSet = array(
                    "email" => $validate_email[0],
                    "tname" => $validate_tname[0],
                    "tdesc" => $validate_tdesc[0],
                    "files" => $fileArray,
                    "successMessage" => $result." ".$tname." ".$tdesc,
                    "errorMessage" => $errorMessage,
                );
                echo json_encode($dataSet);
            }
        }else{
            // response back to add_ticket_form.php
            $dataSet = array(
                "successMessage" => $successMessage,
                "errorMessage" => $errorMessage,
            );
            echo json_encode($dataSet);
        }
    
        
    } catch(Exception $e){
        $error = $e->getMessage();
    }
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        
        $message = 0;
        if(empty($data) || $data == ""){
            $message = 0;
        }else{
            $message = 1;
        }

        return [$data, $message];
    } 
?>