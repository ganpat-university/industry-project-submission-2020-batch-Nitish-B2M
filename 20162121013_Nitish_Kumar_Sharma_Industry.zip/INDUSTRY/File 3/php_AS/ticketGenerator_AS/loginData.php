<?php
    $LoginMessage = '';
    $LoginFlag = 0;

    $email = '';
    $password = '';
    $repassword = '';

    if(array_key_exists('email', $_POST) && array_key_exists('password', $_POST) && array_key_exists('repassword', $_POST)){

        $email = $_POST['email'];
        $password = $_POST['password'];
        $repassword = $_POST['repassword'];

        if(!preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$/", $email)){
            $LoginMessage = 'Please enter valid email address';
            $LoginFlag = 1;
        }else{
            // connect to database
            $conn = mysqli_connect("localhost","root","","help_desk");
            if(!$conn){
                $LoginMessage = "sorry database connection failed";
                $LoginFlag = 1;
            }else{
                $LoginMessage = "database connected successfully";
                $LoginFlag = 0;
                    
                // check user already exists or not
                $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
                $result = mysqli_query($conn, $sql);
                if(mysqli_num_rows($result) > 0){
                    $LoginMessage = 'User Logged in successfully';
                    $LoginFlag = 0;
                    // set session variables
                    session_start();
                    $_SESSION['email'] = $email;
                    $_SESSION['fname'] = mysqli_fetch_assoc($result)['fname'];
                    $_SESSION['role'] = 0;
                    $_SESSION['loginFlag'] = 1;

                } else {
                    $LoginMessage = 'User does not exists';
                    $LoginFlag = 1;
                }                    
            }
        }
    }else{
        $LoginMessage = $_POST['email'];
        $LoginFlag = 1;
    }
    $response = array(
        'LoginMessage' => $LoginMessage,
        'LoginFlag' => $LoginFlag
    );
    echo json_encode($response);
?>