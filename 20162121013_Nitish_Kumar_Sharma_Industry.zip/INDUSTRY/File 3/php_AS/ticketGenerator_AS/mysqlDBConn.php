<?php

    $conn = mysqli_connect("localhost","root","root","help_desk");

    if(!$conn){
        $dbConnecctionMessage = `"<br>------------------------------";
         "<br>Database Connection Failed<br>";
         "------------------------------"`;
        echo $dbConnecctionMessage;

    }else{
        $dbConnecctionMessage = `"<br>------------------------------";
         "<br>Database Connected successfully<br>";
         "------------------------------"`;
        echo $dbConnecctionMessage;
    }

?>
