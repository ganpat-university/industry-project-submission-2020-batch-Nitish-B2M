-- use help_desk
use help_desk;

-- Drop table if exists
DROP TABLE IF EXISTS filePath;

-- Create table
CREATE TABLE filePath (
    id int NOT NULL AUTO_INCREMENT,
    t_id int NULL,
    r_id int NULL,
    filePath varchar(255) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (t_id) REFERENCES tickets(t_id),
    FOREIGN KEY (r_id) REFERENCES replies(r_id)
);

-- alter table tickets add column tname 
ALTER TABLE tickets ADD COLUMN tname varchar(40) NOT NULL;