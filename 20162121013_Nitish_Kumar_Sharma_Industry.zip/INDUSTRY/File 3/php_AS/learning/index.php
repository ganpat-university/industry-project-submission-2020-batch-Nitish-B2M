<?php
    // normal print
    echo "hello\n";

    // two value print
    echo "hello","world\n";

    // single value print .(concat) 
    echo "hello"."world\n";

    // using print
    print("hello\n");

    // string variable
    $name = "nitish";
    echo $name;

    // numeric variable
    $num = 765;
    echo $num;

    // boolean variable
    $bool = true; // false
    echo "<br/>".$bool;

    // null variable
    $null = null;
    echo $null;
    var_dump($null);

    // array variable
    $array = array("js","php","html");
    echo $array[0];

    // string variable using html tag
    echo "<h2>".$name."</h2>";

    // checking data type
    var_dump($name);
    var_dump($num);
    var_dump($bool);

    // play with string
    $name = "nitish";
    echo str_replace("niti", "ya", $name);

    // play with number
    $num = 765;
    echo $num + 10;

    // play with array
    $array = array("js","php","html");
    echo $array[0];
    var_dump($array);
    $array[0] = "css";
    var_dump($array); // array replace
    echo count($array); // array length
    array_push($array,"js"); // array add
    var_dump($array); 

    // play with associative array
    $array = array("js"=>"javascript","php"=>"hypertext preprocessor","html"=>"hyper text markup language");
    echo $array["js"];
    var_dump($array);
    $array["js"] = "js";
    var_dump($array); // array replace
    echo count($array); // array length
    array_push($array,"js"); // array add
    var_dump($array);

    // play with if else
    $num = 10;
    if($num > 10){
        echo "greater than 10";
    }else if($num < 10){
        echo "less than 10";
    }else{
        echo "equal to 10";
    }

    // play with switch case
    $num = 10;
    switch($num){
        case 10:
            echo "equal to 10";
            break;
        case 20:
            echo "equal to 20";
            break;
        default:
            echo "not equal to 10 and 20";
    }

    // play with while loop
    $num = 1;
    while($num <= 10){
        echo $num;
        $num++;
    }

    // play with do while loop
    $num = 1;
    do{
        echo $num;
        $num++;
    }while($num <= 10);

    // play with for loop
    for($num = 1; $num <= 10; $num++){
        echo $num;
    }

    // play with foreach loop
    $array = array("js","php","html");
    foreach($array as $value){
        echo $value;
    }

    // play with function
    function add($num1,$num2){
        return $num1 + $num2;
    }
    echo add(10,20);

    // play with class
    class Person{
        public $name;
        public $age;
        public function __construct($name,$age){
            $this->name = $name;
            $this->age = $age;
        }
        public function get_name(){
            return $this->name;
        }
        public function get_age(){
            return $this->age;
        }
    }
    $person = new Person("nitish",20);
    echo $person->get_name();
    echo $person->get_age();

    // play with form
    if(isset($_POST["submit"])){
        $name = $_POST["name"];
        $age = $_POST["age"];
        echo $name;
        echo $age;
    }

    // play with session
    session_start();

    if(isset($_POST["submit"])){
        $name = $_POST["name"];
        $age = $_POST["age"];
        $_SESSION["name"] = $name;
        $_SESSION["age"] = $age;
        echo $_SESSION["name"];
        echo $_SESSION["age"];
    }

    // play with cookie
    if(isset($_POST["submit"])){
        $name = $_POST["name"];
        $age = $_POST["age"];
        setcookie("name",$name,time() + 86400);
        setcookie("age",$age,time() + 86400);
        echo $_COOKIE["name"];
        echo $_COOKIE["age"];
    }

    // play with file
    $file = fopen("file.txt","w");
    fwrite($file,"hello world");
    fclose($file);

    $file = fopen("file.txt","r");
    echo fread($file,filesize("file.txt"));
    fclose($file);
    
    // play with json
    $array = array("js","php","html");
    $json = json_encode($array);
    echo $json;
    $array = json_decode($json);
    var_dump($array);

    // // play with api
    // $json = file_get_contents("https://jsonplaceholder.typicode.com/todos");
    // $array = json_decode($json);
    // var_dump($array);
    // echo $array[0]->title;

    // play with database
    $conn = mysqli_connect("localhost","root","","learning");
    $sql = "select * from user";
    $result = mysqli_query($conn,$sql);
    $array = mysqli_fetch_all($result,MYSQLI_ASSOC);
    var_dump($array);
?>