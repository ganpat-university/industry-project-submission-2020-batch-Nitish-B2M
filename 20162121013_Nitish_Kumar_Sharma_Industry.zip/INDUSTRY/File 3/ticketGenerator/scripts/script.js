var app = angular.module('ticketGenerator', ['ui.router','ngRoute']).config(['$stateProvider','$routeProvider', '$urlRouterProvider', '$locationProvider',
function($urlRouterProvider,$routeProvider,$stateProvider,$locationProvider ) {
    console.log($urlRouterProvider);
    console.log($routeProvider);
    console.log($locationProvider);
    // $routeProvider.otherwise('home.html');
    $locationProvider.html5Mode(true);
    $routeProvider.caseInsensitiveMatch=true;
    
    $urlRouterProvider.state('main', {
        url: '/main',
        templateUrl: '/templates/main.html',
        controller: 'homeController'
    })
    .state('addTicket', {
        url: '/addTicket',
        templateUrl: '/templates/addTicket.html',
        controller: 'createTicketController'
    })
    .state('viewTicket', {
        url: '/viewTicket',
        templateUrl: '/templates/viewTicket.html',
        controller: 'viewTicketController'
    })
    .state('home', {
        url: '/home',
        templateUrl: '/home.html',
        controller: 'homeController'
    });

}])
.controller('homeController', function($scope) {
    $scope.title = 'This is Home';
})
.controller('createTicketController', function($scope) {
    $scope.title = 'This is Add Ticket';
})
.controller('viewTicketController', function($scope) {
    $scope.title = 'This is View Ticket';
})
.controller('loginController', function($scope) {
    $scope.title = 'This is Login';
})
.controller('registerController', function($scope) {
    $scope.title = 'This is Register';
});